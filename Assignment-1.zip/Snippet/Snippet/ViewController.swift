//
//  ViewController.swift
//  Snippet
//
//  Created by Yogesh Patel on 04/06/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    var arrData = [String]()
    
    override func viewDidLoad() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        arrData = [
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1",
        "1","1","1","1","1","1","1","1"
        ]
        tableView.reloadData()
    }
 
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arrData[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 50))
        headerView.backgroundColor = UIColor.lightGray
        let label = UILabel()
        label.frame = CGRect.init(x: 5, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
        label.text = "iOS Development"
        label.textColor = UIColor.black
        headerView.addSubview(label)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
}
